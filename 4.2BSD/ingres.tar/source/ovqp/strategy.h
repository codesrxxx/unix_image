/*
**  STRATEGY.H
**
**	Version:
**		@(#)strategy.h	7.1	2/5/81
*/

# define	opGTGE	opGT
# define	opLTLE	opLT
