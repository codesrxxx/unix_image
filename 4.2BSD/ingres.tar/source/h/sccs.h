#define SCCSID(arg) static char Sccsid[] = "arg";
